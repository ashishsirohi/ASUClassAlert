/**
 * Created by ashish on 6/24/17.
 */

/*function onload(){
    alert("Hello");
    url = window.location.href;
    alert(url);
    alert(url.substr(url.lastIndexOf("/")+1));

    if(url.split('/').pop() == 'login'){
        alert(url.split('/').pop());
        document.getElementById("signup").style.display="none";
        document.getElementById("login").style.display="block";
    }
    if(url.split('/').pop() == 'signup'){
        alert(url.split('/').pop());
        document.getElementById("signup").style.display="block";
        document.getElementById("login").style.display="none";
    }
}

function showLoginForm() {
    document.getElementById("signup").style.display="none";
    document.getElementById("login").style.display="block";
}

function showSignupForm() {
    document.getElementById("signup").style.display="block";
    document.getElementById("login").style.display="none";
}
*/